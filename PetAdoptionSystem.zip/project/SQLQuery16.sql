Select * from Pet;
exec sp_rename 'Pet.Quantity','Age','Column';