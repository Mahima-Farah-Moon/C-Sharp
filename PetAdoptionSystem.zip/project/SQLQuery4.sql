/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [AdminID]
      ,[AccessCD]
  FROM [petShop].[dbo].[Admin]

 