select * from Vet

exec sp_rename 'Vet.VTimeSc','TimeSc','Column';